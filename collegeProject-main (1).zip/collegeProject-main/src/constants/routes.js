export const HOME = "/";
export const BROWSE = "/browser";
export const SIGN_UP = "/signup";
export const SIGN_IN = "/signin";
