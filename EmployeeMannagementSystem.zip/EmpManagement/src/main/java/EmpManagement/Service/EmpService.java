package EmpManagement.Service;

import org.springframework.beans.factory.annotation.Autowired;

import EmpManagement.entity.Employee;
import EmpManagement.repository.EmpRepo;

public class EmpService {
	
	@Autowired
   private EmpRepo eRepo;
   
	public void addEmp(Employee e) {
		eRepo.save(null);
	}
}
