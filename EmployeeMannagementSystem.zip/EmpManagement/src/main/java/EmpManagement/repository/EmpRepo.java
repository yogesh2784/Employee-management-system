package EmpManagement.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import EmpManagement.entity.Employee;

public interface EmpRepo extends JpaRepository<Employee,Integer>{
	
}


